// Lắng nghe sự kiện khi plugin được chạy
figma.on('run', () => {
    // Hiển thị giao diện người dùng (index.html)
    figma.showUI(__html__, 
        {
            width: 500, height: 300,
        }
        );
  });
  
  let pageCount = 1; // Biến để đánh số trang mới
  
  // Lắng nghe sự kiện khi người dùng nhấp vào nút "Create Page" trên giao diện
  figma.ui.onmessage = (msg) => {
    if (msg.type === 'createNewPage') {
      // Tạo một trang mới và đặt tên cho trang đó
      const newPage = figma.createPage();
      newPage.name = 'Page ' + pageCount;
      pageCount++; // Tăng biến pageCount để đánh số trang tiếp theo
  
      figma.notify('Đã tạo ' + newPage.name); // Hiển thị thông báo
      // (Tùy chọn) Di chuyển đến trang mới vừa tạo
      figma.currentPage = newPage;
    }
  };
  